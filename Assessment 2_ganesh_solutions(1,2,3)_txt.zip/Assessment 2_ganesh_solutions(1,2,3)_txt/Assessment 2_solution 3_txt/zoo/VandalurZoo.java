package zoo;
import org.animals.*;

public class VandalurZoo {

	public static void main(String[] args) {
		Lion l = new Lion();
		l.liondetails();
		l.isvegetarian();
		l.canClimb();
		l.getSound();
		Elephant p = new Elephant();
		p.elephantdetails();
		p.isvegetarian();
		p.canClimb();
		p.getSound();
		Monkey m = new Monkey();
		m.monkeydetails();
		m.isvegetarian();
		m.canClimb();
		m.getSound();
		
		
	}


}


