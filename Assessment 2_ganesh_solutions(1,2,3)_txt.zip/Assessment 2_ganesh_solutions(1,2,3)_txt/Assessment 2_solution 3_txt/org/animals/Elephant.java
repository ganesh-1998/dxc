package org.animals;
public class Elephant {
		String colour ="Grey";
		double weight= 2000.50;
		int age = 15; 
		public void isvegetarian() {
			
			System.out.println("Elephant is a vegetarian");
		}
		public void canClimb() {
			System.out.println("Elephant cannot climb ");
			
		}
		public void getSound() {
			System.out.println("Elephant do sounds\n ");
			
		}
		public void elephantdetails() {
			System.out.println("ELEPHANT DETAILS:\n");
			System.out.println("Elephant Colour is:"+colour);
			System.out.println("Elephant Weight is:"+weight);
			System.out.println("Elephant Age  is:"+age);
		}
		
	}



