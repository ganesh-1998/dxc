package org.animals;
public class Lion {
	String colour ="orange";
	double weight= 300.25;
	int age = 13; 
	public void isvegetarian() {
		
		System.out.println("Lion is a non-vegetarian");
	}
	public void canClimb() {
		System.out.println("Lion can climb ");
		
	}
	public void getSound() {
		System.out.println("Lion do sound(roar)\n");
		
	}
	public void liondetails() {
		System.out.println("LION DETAILS:\n");
		System.out.println("Lion Colour is:"+colour);
		System.out.println("Lion Weight  is:"+weight);
		System.out.println("Lion Age  is:"+age);
	}
		
}
