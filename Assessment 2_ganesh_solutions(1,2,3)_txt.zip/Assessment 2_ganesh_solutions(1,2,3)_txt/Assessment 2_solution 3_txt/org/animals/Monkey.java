package org.animals;
public class Monkey {
	String colour = "grey";
	float weight = 15.3f;
	int age = 7;  
	public void isvegetarian() {
		
		System.out.println("Monkeys are both vegetarian and non-vegetarian");
	}
	public void canClimb() {
		System.out.println("Monkeys can climb ");
		
	}
	public void getSound() {
		System.out.println("Monkeys do sound ");
		
	}
	public void monkeydetails() {
		System.out.println("MONKEY DETAILS:\n");
		System.out.println("Monkey colour is:"+colour);
		System.out.println("Monkey Weight is:"+weight);
		System.out.println("Monkey Age is:"+age);
	}
		
}

