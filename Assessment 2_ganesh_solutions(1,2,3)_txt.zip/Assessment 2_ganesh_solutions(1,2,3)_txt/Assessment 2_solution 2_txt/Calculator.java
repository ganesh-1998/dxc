package Assessment;
public class Calculator {
	public void add(int num1 , int num2) {
		System.out.println(num1+num2);
	}
	public void add(double num1 , double num2) {
		System.out.println(num1+num2);
	}
	public void add(int num1 , double num2) {
		System.out.println(num1+num2);
	}
	public void add(double num1 , int num2) {
		System.out.println(num1+num2);
	}
	public void diff(int num1 , int num2) {
		System.out.println(num1-num2);
	}
	public void diff(double num1 , double num2) {
		System.out.println(num1-num2);
	}
	public void diff(int num1 , double num2) {
		System.out.println(num1-num2);
	}
	public void diff(double num1 , int num2) {
		System.out.println(num1-num2);
	}
	public void mul(int num1 , int num2) {
		System.out.println(num1*num2);
	}
	public void mul(double num1 , double num2) {
		System.out.println(num1*num2);
	}
	public void mul(int num1 , double num2) {
		System.out.println(num1*num2);
	}
	public void mul(double num1 , int num2) {
		System.out.println(num1*num2);
	}
	public void div(int num1 , int num2) {
		System.out.println(num1/num2);
	}
	public void div(double num1 , double num2) {
		System.out.println(num1/num2);
	}
	public void div(int num1 , double num2) {
		System.out.println(num1/num2);
	}
	public void div(double num1 , int num2) {
		System.out.println(num1/num2);
	}
	public static void main(String args[]) {
		Calculator c = new Calculator();
		c.add(5, 10);
		c.add(25.60, 20.40);
		c.add(30, 40.50);
		c.add(50.20, 2);
		c.diff(15, 10);
		c.diff(100.50, 50.25);
		c.diff(75, 3.25);
		c.diff(16.50, 3);
		c.mul(12, 18);
		c.mul(60.25, 20.15);
		c.mul(45, 2.6);
		c.mul(3.5, 4);
		c.div(12, 6);
		c.div(32.6, 4.2);
		c.div(56, 5.3);
		c.div(34.20, 9);
		
	}

}
